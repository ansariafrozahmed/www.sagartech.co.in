<!doctype html>
<html lang="en">
    <head>
    <title>Sagar tech - Web development services in mumbai</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="description" content="Web development services in mumbai, Best web development services that help your business grow.">
    <meta name="keywords" content="Web development services in mumbai, mumbai central,navi mumbai,web designing, #1 Web Designing & Development Company in Mumbai, website designing, web development, website development, website with html, java script, php, website developer near me, WordPress, Wordpress developers, good website developers">
    <meta name="author" content="Ubaid saudagar">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Favicon -->
    <link rel="shortcut icon" href="images/logoonly.jpg" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <!-- bootstrap -->
    <!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">-->
    <!-- REVOLUTION STYLE SHEETS -->
    <!-- main style -->
    <link href="css/style.css" rel="stylesheet" type="text/css" />
    <!-- responsive -->
    <link href="css/responsive.css" rel="stylesheet" type="text/css" />
    <!--<link rel="stylesheet" href="css/index.css">-->
    <!-- custom -->
    <!--<link href="css/custom.css" rel="stylesheet" type="text/css" />-->
    <!--<link href="css/shorcodes.css" rel="stylesheet" type="text/css" />-->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-156939866-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

</script>
</head>
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <title>Hello, world!</title>
  </head>
  <style>
        p {
  -webkit-touch-callout: none !important; /* iOS Safari */
    -webkit-user-select: none !important; /* Safari */
     -khtml-user-select: none !important; /* Konqueror HTML */
       -moz-user-select: none !important; /* Old versions of Firefox */
        -ms-user-select: none !important; /* Internet Explorer/Edge */
            user-select: none !important; /* Non-prefixed version, currently */
             text-align: justify;
    }
    .device-aria .device-blog4 {
        width: 26% !important;
    }
    .img-center-how {
    margin-top: 130px;
}
    @media screen and (min-width: 600px) {
  .img-center-how {
    margin-top: 130px;
  }
}
#buttonbounce {

    width: 45px;
    height: 45px;
    position: absolute;
    top:30px;
    left: 0%;
    
}

.bounce {
	
	bottom: 30px;
	left: 50% ;

    margin-left: 55px;
	animation: bounce 2s infinite;
	-webkit-animation: bounce 2s infinite;
	-moz-animation: bounce 2s infinite;
	-o-animation: bounce 2s infinite;
}

@-webkit-keyframes bounce {
	0%, 20%, 50%, 80%, 100% {-webkit-transform: translateY(0);}	
	40% {-webkit-transform: translateY(-30px);}
	60% {-webkit-transform: translateY(-15px);}
}
 
@-moz-keyframes bounce {
	0%, 20%, 50%, 80%, 100% {-moz-transform: translateY(0);}
	40% {-moz-transform: translateY(-30px);}
	60% {-moz-transform: translateY(-15px);}
}
 
@-o-keyframes bounce {
	0%, 20%, 50%, 80%, 100% {-o-transform: translateY(0);}
	40% {-o-transform: translateY(-30px);}
	60% {-o-transform: translateY(-15px);}
}
@keyframes bounce {
	0%, 20%, 50%, 80%, 100% {transform: translateY(0);}
	40% {transform: translateY(-30px);}
	60% {transform: translateY(-15px);}
}

.web-service-color{
    /* background-image: radial-gradient(circle at center,#222222 58%,#ff0808 100%)!important; */
    background-color: #ff0805;
    padding: 40px 0px;
    margin: 0px 0px;
}  

.web-heading h4{
    color: black;
    font-size: 22px;
}

.web-content{
    background-color: white;
    margin: 40px 47px;
    border-radius: 8px;
}

.web-service-heading{
    color: white;
    font-weight: 600;
    font-size: 50px;
    margin: 40px 0px;
}

.card{
    background: #f8f8f8;
    padding: 20px;
    -webkit-transition: all .5s ease-in-out;
    -o-transition: all .5s ease-in-out;
    transition: all .5s ease-in-out;
}

.cardz{
    
  padding:20px;
  text-align: center;
  position: relative;
  display: inline-block;
  background-color: #fff;
  border-radius: 2px;
  box-shadow: 0 50px 150px rgba(0, 0, 0, 0.1);
  border-radius: 6px;
  -webkit-transition: all 0.6s cubic-bezier(0.165, 0.84, 0.44, 1);
  transition: all 0.6s cubic-bezier(0.165, 0.84, 0.44, 1);
}

.cardz::after {
    content: "";
    border-radius: 5px;
    position: absolute;
    z-index: -1;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    -webkit-box-shadow: 0px 14px 16px -8px rgba(0,0,0,0.75);
    -moz-box-shadow: 0px 14px 16px -8px rgba(0,0,0,0.75);
    box-shadow: 0px 14px 16px -8px rgba(0,0,0,0.75);
    opacity: 0;
    -webkit-transition: all 0.6s cubic-bezier(0.165, 0.84, 0.44, 1);
    transition: all 0.6s cubic-bezier(0.165, 0.84, 0.44, 1);
  }
  
  .cardz:hover {
    -webkit-transform: scale(1.15, 1.15);
    transform: scale(1.15, 1.15);
  }

  .cardz:hover::after {
    opacity: 1;
}


.step-heading{
    margin: 40px 0px;
    font-weight: 600;
    font-size: 50px;
}

.step-design{
    border-top: 7px solid #ff0808;
    border-bottom: 1px solid #ff0808;
    border-left: 1px solid #ff0808;
    border-right: 1px solid #ff0808;
    padding-top: 10px;
    background-color: white;
}


.step-number{
    height: 40px;
    width: 40px;
    background-color: #ff0808;
    color: white;
    border-radius: 100%;
    float: right;
    margin-right: 30px;
    margin-top: -21px;
}
.step-number p{
    text-align: center;
    padding:8px 0px ;
}


/* Slider */

.slick-slide {
    margin: 0px 20px;
}

.slick-slide img {
    width: 100%;
}

.slick-slider
{
    position: relative;
    display: block;
    box-sizing: border-box;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
            user-select: none;
    -webkit-touch-callout: none;
    -khtml-user-select: none;
    -ms-touch-action: pan-y;
        touch-action: pan-y;
    -webkit-tap-highlight-color: transparent;
}

.slick-list
{
    position: relative;
    display: block;
    overflow: hidden;
    margin: 0;
    padding: 0;
}
.slick-list:focus
{
    outline: none;
}
.slick-list.dragging
{
    cursor: pointer;
    cursor: hand;
}

.slick-slider .slick-track,
.slick-slider .slick-list
{
    -webkit-transform: translate3d(0, 0, 0);
       -moz-transform: translate3d(0, 0, 0);
        -ms-transform: translate3d(0, 0, 0);
         -o-transform: translate3d(0, 0, 0);
            transform: translate3d(0, 0, 0);
}

.slick-track
{
    position: relative;
    top: 0;
    left: 0;
    display: block;
}
.slick-track:before,
.slick-track:after
{
    display: table;
    content: '';
}
.slick-track:after
{
    clear: both;
}
.slick-loading .slick-track
{
    visibility: hidden;
}

.slick-slide
{
    display: none;
    float: left;
    height: 100%;
    min-height: 1px;
}
[dir='rtl'] .slick-slide
{
    float: right;
}
.slick-slide img
{
    display: block;
}
.slick-slide.slick-loading img
{
    display: none;
}
.slick-slide.dragging img
{
    pointer-events: none;
}
.slick-initialized .slick-slide
{
    display: block;
}
.slick-loading .slick-slide
{
    visibility: hidden;
}
.slick-vertical .slick-slide
{
    display: block;
    height: auto;
    border: 1px solid transparent;
}
.slick-arrow.slick-hidden {
    display: none;
}

.design-bg{
    background-image: url('../images/bg.png');
}

.web-services{
    cursor: pointer;
}


.carousel-item h4{
    font-size: 16px;
    font-weight: 500;
}

.carousel-item .card{
    padding: 0px;
    /* background-color: #ff0808; */
    color: white;
}
/* 
.carousel-item .card-body a{
  color: white;
}

.carousel-item .card-body a h4{
  color: white;
} */

.carousel-item .date p{
    margin: 0 auto;
    font-weight: 500;
    background-color: black;
    color: white;
    width: 100px;
    text-align: center;
    border-radius: 5px;
}

.carousel-item .card-body{
    text-align: center;
}
#map {
  height: 100%;
}
html, body {
  height: 100%;
  margin: 0;
  padding: 0;
}
  </style>
  <body>
    <h1>Hello, world!</h1>
<div id="map"></div>
<!-- Replace the value of the key parameter with your own API key. -->
<script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA_Vs2cmta4aD2T7LxD296dDp-iD7IanOA&callback=initMap"></script>
<script>
    // The following example creates complex markers to indicate beaches near
// Sydney, NSW, Australia. Note that the anchor is set to (0,32) to correspond
// to the base of the flagpole.

function initMap() {
  var map = new google.maps.Map(document.getElementById('map'), {
    zoom: 10,
    center: {lat: 14.4440919, lng: 54.055893}
  });

  setMarkers(map);
}

// Data for the markers consisting of a name, a LatLng and a zIndex for the
// order in which these markers should display on top of each other.
var beaches = [
 
  ['INDIA',22.4618213, 76.3962699,1],
  ['SAUDI ARABIA',24.5161634,37.359677,2],
  ['DUBAI',25.0757073, 54.9475464,3],
  ['MALAWI',-13.1982556, 29.7963733,4]
];

function setMarkers(map) {
  // Adds markers to the map.

  // Marker sizes are expressed as a Size of X,Y where the origin of the image
  // (0,0) is located in the top left of the image.

  // Origins, anchor positions and coordinates of the marker increase in the X
  // direction to the right and in the Y direction down.
  
  // Shapes define the clickable region of the icon. The type defines an HTML
  // <area> element 'poly' which traces out a polygon as a series of X,Y points.
  // The final coordinate closes the poly by connecting to the first coordinate.
  var shape = {
    coords: [1, 1, 1, 20, 18, 20, 18, 1],
    type: 'poly'
  };
  for (var i = 0; i < beaches.length; i++) {
    var beach = beaches[i];
    var marker = new google.maps.Marker({
      position: {lat: beach[1], lng: beach[2]},
      map: map,
      shape: shape,
      title: beach[0],
      zIndex: beach[3]
    });
    marker.setAnimation(google.maps.Animation.BOUNCE);
  }
}
</script>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
        <script src="js/jquery.min.js"></script>
 <script src="js/popper.min.js"></script>
    <!--  bootstrap -->
    <script src="js/bootstrap.min.js"></script>
    <!-- Google captcha code Js -->
    <!--<script src='../../../../www.google.com/recaptcha/api.js'></script>-->
    <!-- Mega Menu -->
    <script src="js/mega-menu/mega_menu.js"></script>
    <!-- Main -->
    <!--<script src="js/main.js"></script>-->
    <!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>-->

    <!--<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

    <!-- style-customizer -->
    <script src="js/style-customizer.js"></script>
    <!-- price_range_script -->
    <script src="js/price_range_script.js"></script>
    <!-- modernizr.custom -->
    <script src="js/modernizr.custom.js"></script>
    <!-- jquerypp.custom -->
    <script src="js/jquerypp.custom.js"></script>
    <!-- bookblock -->
    <script src="js/jquery.bookblock.js"></script>
    <!-- Custom -->
    <script src="js/custom.js"></script>
    <!-- END REVOLUTION SLIDER -->
    <script src="js/noclick.js"></script>
    
    
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.form/4.2.2/jquery.form.min.js"></script> 
    <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.6.0/slick.js"></script>
    
  </body>
</html>