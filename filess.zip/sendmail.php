<?php

	
   //require 'PHPMailer/PHPMailerAutoload.php';

   if (isset($_POST['name'])) {
      // echo "hello";
      $email = $_POST['email'];
      $phone = $_POST['phone'];
      $message = $_POST['msg'];
      $name=$_POST['name'];

$subject = "Enquiry from ".$name;
$mailFrom="info@sagartech.co.in";
$headers="From:mail.sagartech.co.in";
$to="$mailFrom";
$txt="Name: $name
\nEmail: $email
\nPhone: $phone
\nMsg: $message";

if(mail($to, $subject, $txt, "https://sagartech.co.in/"))    //https://sagartech.co.in/
{
   echo "1";

}
else
{
  echo "0";

}      

    /*  $mail = new PHPMailer();

      
    $mail->Host = 'mail.sagartech.co.in';
    $mail->isSMTP();
    $mail->SMTPAuth = true;
    $mail->Username = 'sender@sagartech.co.in';
    $mail->Password = 'KN3MPPFair=0';
    $mail->SMTPSecure = 'tls'; //TLS
    $mail->Port = 587; //587

    $mail->setFrom($_POST['email'],$_POST['name']);
    $mail->addAddress('info@sagartech.co.in','Sagartech');
    $mail->addReplyTo($_POST['email'],$_POST['name']);
    $mail->Subject = "Enquiry from ".$name;
    $mail->isHTML(true);
    $mail->Body ='<h1>Name:'.$_POST['name'].'<br>Email:'.$_POST['email'].'<br>Phone:'.$_POST['phone'].'<br>Msg:'.$_POST['msg'].'</h1>';
    
 
    if (!$mail->send()){
       echo "0";
      }
    else
      {
         echo "1";
      }*/
}
else if(isset($_POST['quote_submit'])) {
    $service = $_POST['service'];
    $fname = $_POST['fname'];
    $mobile = $_POST['mobile'];
    $addwords = $_POST['addwords'];
    $emails = $_POST['email1'];
    
    $subject = "Quote Requested for".$service;
    $mailFrom="info@sagartech.co.in";
    $headers="From:mail.sagartech.co.in";
    $to="$mailFrom";
//    $txt='<h1>Name:'.$_POST['fname'].'<br>Email:'.$_POST['email1'].'<br>Phone:'.$_POST['mobile'].'<br>Additional Words:'.$_POST['addwords'].'</h1>';
    $txt="Name: $fname
\nEmail: $emails
\nPhone: $mobile
\nAdditional Words:: $addwords";
    if(mail($to, $subject, $txt, "https://sagartech.co.in/"))    //https://sagartech.co.in/
    {
       echo "1";
    
    }
    else
    {
      echo "0";
    
    }      
   /* $mail = new PHPMailer();

      
    $mail->Host = 'mail.sagartech.co.in';
    $mail->isSMTP();
    $mail->SMTPAuth = true;
    $mail->Username = 'sender@sagartech.co.in';
    $mail->Password = 'KN3MPPFair=0';
    $mail->SMTPSecure = 'tls'; //TLS
    $mail->Port = 587; //587

    $mail->setFrom($_POST['email1'],$_POST['fname']);
    $mail->addAddress('info@sagartech.co.in','Sagartech');//
    $mail->addReplyTo($_POST['email1'],$_POST['fname']);
    $mail->Subject = "Quote Requested for".$service;
    $mail->isHTML(true);
    $mail->Body ='<h1>Name:'.$_POST['fname'].'<br>Email:'.$_POST['email1'].'<br>Phone:'.$_POST['mobile'].'<br>Additional Words:'.$_POST['addwords'].'</h1>';
    

    if (!$mail->send()){
       echo "0";
      }
    else
      {
         echo "1";
      }*/
}

?>