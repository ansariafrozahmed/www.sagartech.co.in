<!doctype html>
<html lang="en">


<!-- Mirrored from iqonicthemes.com/themes/qwilo/qwilo/full-classic-4-portfolio.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 05 Oct 2019 14:24:27 GMT -->
<head>
    <title>Sagar Tech - Technical Solutions</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Favicon -->
    <link rel="shortcut icon" href="images/logoonly.jpg" />
   <!-- bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <!-- REVOLUTION STYLE SHEETS -->
    <link href="revolution/css/settings.css" rel="stylesheet" type="text/css">
    <!-- ADD-ONS CSS FILES -->
    <link href="revolution/css/revolution.addon.particles.css" rel="stylesheet" type="text/css">
    <!-- main style -->
    <link href="css/style.css" rel="stylesheet" type="text/css" />
    <!-- responsive -->
    <link href="css/responsive.css" rel="stylesheet" type="text/css" />
    <!-- custom -->
    <link href="css/custom.css" rel="stylesheet" type="text/css" />
    
    
</head>

<body>
    <!-- loading -->
    <div id="loading">
        <div id="loading-center">
            <img src="images/logoonly.jpg" alt="loder">
        </div>
    </div>
    <!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5def76bd43be710e1d216625/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
    <!-- loading End -->
    <!-- HEADER  -->
    <?php 
    $page = 'home';
    include("include/header2.php"); ?>
    <!-- /HEADER END -->
    <!-- search -->
<!--     <div class="search">
        <button id="btn-search-close" class="btn btn--search-close" aria-label="Close search form">
            <i class="fa fa-close" aria-hidden="true"></i>
        </button>
        <form class="search__form">
            <input class="search__input" name="search" type="search" placeholder="Qwilo Search" autocomplete="off" autocapitalize="off" spellcheck="false">
            <span class="search__info">Hit enter to search or ESC to close</span>
        </form>
        <div class="search__related">
            <div class="search__suggestion iq-font-white">
                <h3 class="iq-font-white iq-tw-6">May We Suggest?</h3>
                <p>#drone #funny #catgif #broken #lost #hilarious #good #red #blue #nono #why #yes #yesyes #aliens #green</p>
            </div>
            <div class="search__suggestion iq-font-white">
                <h3 class="iq-font-white iq-tw-6">Is It This?</h3>
                <p>#good #red #hilarious #blue #nono #why #yes #yesyes #aliens #green #drone #funny #catgif #broken #lost</p>
            </div>
            <div class="search__suggestion iq-font-white">
                <h3 class="iq-font-white iq-tw-6">Where Art Thou?</h3>
                <p>#broken #lost #good #red #funny #hilarious #catgif #blue #nono #why #yes #yesyes #aliens #green #drone</p>
            </div>
        </div>
    </div> -->
    <!-- /search END -->
<!--======= Breadcrumb Left With BG Image =======-->
    <section class="overview-block-ptb iq-over-black-70 jarallax iq-breadcrumb3 text-left iq-font-white" style="background-image: url('images/payment.png'); background-position: center center; background-repeat: no-repeat; background-size: cover;">
        <div class="container">
            <div class="row align-items-center">
            <div class="col-lg-4">
             <div class="iq-mb-0">
             <h2 class="iq-font-white iq-tw-6">Payment</h2>
            </div>
          </div>
         <div class="col-lg-8">
          <nav aria-label="breadcrumb" class="text-right">
           <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index"><i class="ion-android-home"></i> Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">Payment</li>
          </ol>
         </nav> 
       </div>
        </div>
        </div>
    </section>
    <!--======= Breadcrumb Left With BG Image =======-->

    <!--=================================
        Main Content -->
            <!-- <div class="razorpay-embed-btn" data-url="https://rzp.io/l/lgYMQML" data-text="Pay Now" data-color="#FF0808" data-size="large"  style="max-height: 100px; text-align: center; margin-top: 65px;">
                <script>
                (function(){
                  var d=document; var x=!d.getElementById('razorpay-embed-btn-js')
                  if(x){ var s=d.createElement('script'); s.defer=!0;s.id='razorpay-embed-btn-js';
                  s.src='https://cdn.razorpay.com/static/embed_btn/bundle.js';d.body.appendChild(s);} else{var rzp=window['_rzp_'];
                  rzp && rzp.init && rzp.init()}})();
                </script>
            </div> -->

            <div class="razorpay-embed-btn" data-url="https://rzp.io/l/5UkM4jX" data-text="Pay Now" data-color="#FF0808" data-size="large" style="max-height: 100px; text-align: center; margin: 65px;">
             <script>
               (function(){
                 var d=document; var x=!d.getElementById('razorpay-embed-btn-js')
                 if(x){ var s=d.createElement('script'); s.defer=!0;s.id='razorpay-embed-btn-js';
                 s.src='https://cdn.razorpay.com/static/embed_btn/bundle.js';d.body.appendChild(s);} else{var rzp=window['__rzp__'];
                 rzp && rzp.init && rzp.init()}})();
             </script>
            </div>
            <!--=================================
            Main Content -->
            <!--=================================
            Footer -->
            <?php include("include/footer.php"); ?>
        <!--=================================
        Footer -->

    <!-- back-to-top -->
    <div id="back-to-top">
        <a class="top" id="top" href="#top"> <i class="ion-ios-arrow-up"></i> </a>
    </div>
    <!-- back-to-top End -->
    
    
     <!--================ Jquery =================-->
    <!-- Jquery  -->
    <script src="js/jquery.min.js"></script>
    <!-- popper  -->
    <script src="js/popper.min.js"></script>
    <!--  bootstrap -->
    <script src="js/bootstrap.min.js"></script>
    <!-- Google captcha code Js -->
    <script src='../../../../www.google.com/recaptcha/api.js'></script>
    <!-- Mega Menu -->
    <script src="js/mega-menu/mega_menu.js"></script>
    <!-- Main -->
    <script src="js/main.js"></script>

    
    <!-- price_range_script -->
    <script src="js/price_range_script.js"></script> 
    <!-- modernizr.custom -->
    <script src="js/modernizr.custom.js"></script> 
    <!-- jquerypp.custom -->
    <script src="js/jquerypp.custom.js"></script> 
    <!-- bookblock -->
    <script src="js/jquery.bookblock.js"></script> 
    <!-- style-customizer-->
    <script src="js/style-customizer.js"></script>
    <!-- Custom -->
    <script src="js/custom.js"></script>
    
    <script src="js/noclick.js"></script>

    <!-- WhatsHelp.io widget -->
<script type="text/javascript">
    $(document).ready(function() {
        
        $('body').bind('cut copy paste', function (e) {
              e.preventDefault();
          });
    })
    (function () {
        var options = {
            whatsapp: "+919820133303", // WhatsApp number
            call_to_action: "Message us", // Call to action
            position: "left", // Position may be 'right' or 'left'
        };
        var proto = document.location.protocol, host = "getbutton.io", url = proto + "//static." + host;
        var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = url + '/widget-send-button/js/init.js';
        s.onload = function () { WhWidgetSendButton.init(host, proto, options); };
        var x = document.getElementsByTagName('script')[0]; x.parentNode.insertBefore(s, x);
    })();
</script>
<!-- /WhatsHelp.io widget -->   
</body>


<!-- Mirrored from iqonicthemes.com/themes/qwilo/qwilo/full-classic-4-portfolio.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 05 Oct 2019 14:24:27 GMT -->
</html>